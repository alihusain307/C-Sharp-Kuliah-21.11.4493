﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrinterWindow
{
    public class Canon : PrinterWindow
    {
        public override void Show()
        {
            Console.WriteLine("Canon Dispay Dimension : 9.5*12");
        }
        public override void Print()
        {
            Console.WriteLine("Canon Printer Printing...");
        }
    }
}
