﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrinterWindow
{
    public class Epson : PrinterWindow
    {
        public override void Show()
        {
            Console.WriteLine("Epson Dispay Dimension : 10*11");
        }
        public override void Print()
        {
            Console.WriteLine("Epson Printer Printing...");
        }
    }
}
